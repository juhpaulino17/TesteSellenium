package Paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import ConfiguracaoGeral.Geral;

public class FormularioVehicleDataPagina extends Geral {


	public static  WebElement  combomarca(WebDriver navegador) {
		WebElement combomarca = navegador.findElement(By.id("make"));
		Select select = new Select(combomarca);
		select.selectByVisibleText("BMW");
		return combomarca;
		
	}
		

	public static WebElement campodesempenhodomotor(WebDriver navegador) {
		navegador.findElement(By.name("[kW]")).sendKeys(desempenhomotor);

	}

	public static WebElement datadefabricacao(WebDriver navegador) {
		return navegador.findElement(By.xpath("//*[@id='dateofmanufacture']"));
	}

	public static WebElement numerodeassentos (WebDriver navegador) {
     WebElement	numerodeassentos	=	navegador.findElement(By.id("numberofseats"));
       Select	select	=	new	Select(numerodeassentos);
        select.selectByVisibleText("5");
		return numerodeassentos;
	
	}
	public static WebElement tipodecompustivel (WebDriver navegador) {
	     WebElement	tipodecompustivel	=	navegador.findElement(By.id("fuel"));
	       Select	select	=	new	Select(tipodecompustivel);
	        select.selectByVisibleText("Petrol");
			return tipodecompustivel;
	       
	}
	public static WebElement precotabela (WebDriver navegador) {
		navegador.findElement(By.id("listprice")).sendKeys(precotabela);	
	
}
	public static WebElement numeromatricula (WebDriver navegador) {
		navegador.findElement(By.id("licenseplatenumber")).sendKeys(numeromatricula);
		
	}
	public static WebElement milhagemanual (WebDriver navegador) {
			navegador.findElement(By.id("annualmileage")).sendKeys(milhagemanual);
			
	}
			
			public static WebElement proximapagina (WebDriver navegador) {
		  return navegador.findElement(By.xpath("//*[@id='nextenterproductdata']"));
			    }	
			
		}
		


	
