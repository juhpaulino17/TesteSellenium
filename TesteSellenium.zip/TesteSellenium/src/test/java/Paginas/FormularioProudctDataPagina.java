package Paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import ConfiguracaoGeral.Geral;

public class FormularioProudctDataPagina extends Geral
{
	
	public static WebElement datadeinico (WebDriver navegador) {
		return navegador.findElement(By.xpath("//*[@id='startdate']"));
	}
		
		
		 public static WebElement valorseguro (WebDriver navegador) {
				WebElement valorseguro = navegador.findElement(By.id("insurancesum"));
				Select select = new Select(valorseguro);
				select.selectByVisibleText("7000000");
				
		 }
		 
		 public static WebElement classificacaomerito (WebDriver navegador) {
				WebElement classificacaomerito = navegador.findElement(By.id("meritrating"));
				Select select = new Select(classificacaomerito);
				select.selectByVisibleText("Bonus 4");
				
		 }
		 public static WebElement segurodedanos (WebDriver navegador) {
		WebElement segurodedanos = navegador.findElement(By.id("damageinsurance"));
		Select select = new Select(segurodedanos);
		select.selectByVisibleText("Full Coverage");
		 }
		 
		public static WebElement campoProdutos (WebDriver navegador) {
	        return navegador.findElement(By.xpath("//*[@id='insurance-form']/div/section[3]/div[5]/p/label[1]/span"));
	    }
		
		 public static WebElement carrocortesia (WebDriver navegador) {
				WebElement carrocortesia = navegador.findElement(By.id("courtesycar"));
				Select select = new Select(carrocortesia);
				select.selectByVisibleText("Yes");
				
		 }
				 
}
		
	