package Paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ConfiguracaoGeral.Geral;

public class FormularioSendQuotePagina extends Geral {

	public static WebElement email(WebDriver navegador) {
		navegador.findElement(By.id("email")).sendKeys(email);

	}

	public static WebElement telefone(WebDriver navegador) {
		navegador.findElement(By.id("phone")).sendKeys(telefone);

	}

	public static WebElement usuario(WebDriver navegador) {
		navegador.findElement(By.id("username")).sendKeys(usuario);
	}

	public static WebElement senha(WebDriver navegador) {
		navegador.findElement(By.id("password")).sendKeys(senha);
	}

	public static WebElement repitirsenha(WebDriver navegador) {
		navegador.findElement(By.id("confirmpassword")).sendKeys(repitirsenha);

	}

	public static WebElement comentarios(WebDriver navegador) {
		navegador.findElement(By.id("Comments")).sendKeys(comentarios);

	}
		 public static WebElement enviar (WebDriver navegador) {
		        return navegador.findElement(By.xpath("//*[@id='sendemail']"));
    }

		    public static WebElement enviovalido (WebDriver navegador) {
		        return navegador.findElement(By.cssSelector("body>div.sweet-alert.showSweetAlert.visible>h2"));    
}
		    public static WebElement confirmar (WebDriver navegador) {
      return navegador.findElement(By.cssSelector("body>div.sweet-alert.showSweetAlert.visible>div.sa-button-container>div>button"));
		    }

	}


