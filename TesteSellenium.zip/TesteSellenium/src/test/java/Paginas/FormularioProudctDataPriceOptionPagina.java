package Paginas;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import ConfiguracaoGeral.Geral;

public class FormularioProudctDataPriceOptionPagina extends Geral {
	
	
	public static WebElement plano (WebDriver navegador) {
		WebElement plano = navegador.findElement(By.id("selectultimate"));
		Select select = new Select(plano);
		select.selectByVisibleText("Ultimate");
		return plano;
	    }

	    public static WebElement proximapagina (WebDriver browser) {
	        return browser.findElement(By.xpath("//*[@id='nextsendquote']"));
	    }
	    
	}


