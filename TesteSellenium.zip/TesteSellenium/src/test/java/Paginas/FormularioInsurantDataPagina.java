package Paginas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import ConfiguracaoGeral.Geral;

public class FormularioInsurantDataPagina extends Geral {

public static WebElement primeironome (WebDriver navegador) {
	  navegador.findElement(By.id("firstname")).sendKeys(primeironome));
	  
 public static WebElement sobrenome (WebDriver navegador) {
	navegador.findElement(By.id("lastname")).sendKeys(sobrenome);
	
public static WebElement datadenascimento (WebDriver navegador) {
 return navegador.findElement(By.xpath("//*[@id='birthdate']"));
	
public static WebElement sexo (WebDriver navegador) {
	navegador.findElement(By.xpath("//input[@value='male']")).click();
		        	
 public static WebElement endereco (WebDriver navegador) {
navegador.findElement(By.id("streetaddress")).sendKeys(endereco);

public static WebElement pais (WebDriver navegador) {
	WebElement pais = navegador.findElement(By.id("country"));
	Select select = new Select(pais);
	select.selectByVisibleText("Australia");
	
	public static WebElement codigopostal (WebDriver navegador) {
		  navegador.findElement(By.id("zipcode")).sendKeys(codigopostal);

 public static WebElement cidade (WebDriver navegador) {
			  navegador.findElement(By.id("city")).sendKeys(cidade);
			  
 public static WebElement ocupacao (WebDriver navegador) {
					WebElement pais = navegador.findElement(By.id("occupation"));
					Select select = new Select(pais);
					select.selectByVisibleText("Farmer");

	public static WebElement hobbie (WebDriver navegador) {
				navegador.findElement(By.xpath("//input[@value='Employee']")).click();
				
				public static WebElement perfilsite (WebDriver navegador) {
					  navegador.findElement(By.id("website")).sendKeys(perfilsite);
					  
	public static WebElement proximapagina (WebDriver browser) {
	 return browser.findElement(By.xpath("//*[@id='nextenterproductdata']"))
  }
}
