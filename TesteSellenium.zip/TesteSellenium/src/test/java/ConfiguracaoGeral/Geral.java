package ConfiguracaoGeral;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Geral {
	
	  public static WebDriver navergador;
	    
	    public static void iniciar(String url){
	      
	      if(navergador == null){
	        System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
	        navergador = new ChromeDriver();
	      }
	  
	      navergador.get(url);
	      navergador.manage().window().maximize();
	    }

	    public static void navegador(String string) {
	    }

		public static void inicia(String url){
		
		}
	    	
	}
