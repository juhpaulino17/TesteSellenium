package steps;

import ConfiguracaoGeral.Geral;
import Paginas.FormularioProudctDataPagina;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;

public class FormularioProudctDataSteps extends Geral{
	
	
	@Dado("informo  a data de inicio")
	public void informo_a_data_de_inicio() {FormularioProudctDataPagina.datadeinico(navergador).sendKeys("05/10/2022");
}
	@Dado("seleciono soma do seguro [$]")
	public void seleciono_soma_do_seguro_$() {FormularioProudctDataPagina.valorseguro(navergador).click();
	}

	@Dado("seleciono uma classificação de mérito")
	public void seleciono_uma_classificação_de_mérito()  {FormularioProudctDataPagina.classificacaomerito(navergador).click();
	}

	@Dado("seleciono um seguro de Danos")
	public void seleciono_um_seguro_de_danos() { FormularioProudctDataPagina.segurodedanos(navergador).click();
		
	}

	@Dado("seleciono no minimo um Produtos Opcionais")
	public void seleciono_no_minimo_um_produtos_opcionais(){FormularioProudctDataPagina.campoProdutos(navergador).click();
	}

	@Dado("seleciono uma opcão carro de cortesia")
	public void seleciono_uma_opcão_carro_de_cortesia()  {FormularioProudctDataPagina.carrocortesia(navergador).click();
		
	}

	@Entao("clico em next para ir para o Price Option")
	public void clico_em_next_para_ir_para_o_price_option() {
	}
	

}
