package steps;

import ConfiguracaoGeral.Geral;
import Paginas.FormularioVehicleDataPagina;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.E;
import io.cucumber.java.pt.Entao;

public class FormularioVehicleDataPaginaSteps extends Geral
{
	@Dado("que estou no site da tricentis")
	public void que_estou_no_site_da_tricentis() { Geral.iniciar("http://sampleapp.tricentis.com/101/app.php");

	  }

	@E("seleciono uma marca")
	public  void seleciono_uma_marca() { FormularioVehicleDataPagina.campodesempenhodomotor(navergador).click();
	}

	@E("digito o desempenho do motor em [kW]")
	public void digito_o_desempenho_do_motor_em_k_w() { FormularioVehicleDataPagina.campodesempenhodomotor(navergador).sendKeys("105");
	}
	    
	@E("informo a data de fabricação")
	public void informo_a_data_de_fabricação() { FormularioVehicleDataPagina.datadefabricacao(navergador).sendKeys("10/02/2020");
	}
	
	@E("seleciono o número de assentos")
	public void seleciono_o_número_de_assentos() { FormularioVehicleDataPagina.numerodeassentos(navergador).click();
	}
	

	@E("seleciono o tipo de combustível")
	public void seleciono_o_tipo_de_combustível() {FormularioVehicleDataPagina.tipodecompustivel(navergador).click();
	}
	

	@E("digito preço de tabela [$]")
	public void digito_preço_de_tabela_$() {FormularioVehicleDataPagina.precotabela(navergador).sendKeys("25000");
	}

	@E("digito numero da matrícula")
	public void digito_numero_da_matrícula() {FormularioVehicleDataPagina.numeromatricula(navergador).sendKeys("RHS2220");
	}

	@E("digito milhagem anual [MI]")
	public void digito_milhagem_anual_mi() {FormularioVehicleDataPagina.milhagemanual(navergador).sendKeys("5891")	;
	}
	

	@Entao("clico no botão next para ir paro o insurant data")
	public void clico_no_botão_next_para_ir_paro_o_insurant_data() {FormularioVehicleDataPagina.proximapagina(navergador).click();
	
	}

	}

