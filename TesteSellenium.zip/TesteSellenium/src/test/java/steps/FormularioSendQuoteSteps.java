package steps;

import ConfiguracaoGeral.Geral;
import Paginas.FormularioSendQuotePagina;
import Paginas.FormularioVehicleDataPagina;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;

public class FormularioSendQuoteSteps extends Geral {

	@Dado("digito um email")
	public void digito_um_email() {
		FormularioSendQuotePagina.email(navergador).sendKeys("usuario@gmail.com");
	}

	@Dado("digito um telefone")
	public void digito_um_telefone() {
		FormularioSendQuotePagina.telefone(navergador).sendKeys("5544991689845");
	}

	@Dado("escolho um nome de usuario")
	public void escolho_um_nome_de_usuario() {
		FormularioSendQuotePagina.usuario(navergador).sendKeys("Robertoabx");
	}

	@Dado("escolho uma senha")
	public void escolho_uma_senha() {
		FormularioSendQuotePagina.senha(navergador).sendKeys("aseT3Wa2");
	}

	@Dado("repito a senha")
	public void repito_a_senha() {
		FormularioSendQuotePagina.repitirsenha(navergador).sendKeys("aseT3Wa2");
	}

	@Dado("digito comentários")
	public void digito_comentários() {
		FormularioSendQuotePagina.comentarios(navergador).sendKeys("Obrigada aguardo retorno.");
	}

	@Quando("clico em Send")
	public void clico_em_send() {
}

	@Entao("Verifico a mensagem {string}")
	public void verifico_a_mensagem(String string) {
	}

	@Entao("clico no botao Ok")
	public void clico_no_botao_ok() {

	}

}
