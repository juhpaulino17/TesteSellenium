package steps;

import ConfiguracaoGeral.Geral;
import Paginas.FormularioProudctDataPriceOptionPagina;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;


public class FormularioProudctDataPriceOptionSteps extends Geral{
	
	
	@Dado("escolho uma opção")
	public void escolho_uma_opção() {FormularioProudctDataPriceOptionPagina.plano(navergador).click();
	
	}

	@Entao("clico em Next para o Send Quote")
	public void clico_em_next_para_o_send_quote() {FormularioProudctDataPriceOptionPagina.proximapagina(navergador).click();
	}
}
