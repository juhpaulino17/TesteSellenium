package steps;

import ConfiguracaoGeral.Geral;
import Paginas.FormularioInsurantDataPagina;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;

public class FormularioInsurantDataSteps extends Geral{
	


	@Dado("digito o primeiro nome")
	public void digito_o_primeiro_nome() { FormularioInsurantDataPagina.primeironome(navergador).sendKeys("Carlos");
	
	}

	@Dado("digito o sobrenome")
	public void digito_o_sobrenome() { FormularioInsurantDataPagina.sobrenome(navergador).sendKeys("Rodrigues");
	
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Dado("informo a data de nascimento")
	public void informo_a_data_de_nascimento() { FormularioInsurantDataPagina.datadenascimento(navergador).sendKeys("02/05/1985");
	}

	@Dado("seleciono um  gênero")
	public void seleciono_um_gênero() { FormularioInsurantDataPagina.sexo(navergador).click();
	}

	@Dado("digito o endereço")
	public void digito_o_endereço() {FormularioInsurantDataPagina.endereco(navergador).sendKeys("Rua Souza Naves 343");
	
	}

	@Dado("seleciono um país")
	public void seleciono_um_país() {FormularioInsurantDataPagina.pais(navergador).click();
	    
	}
	
	@Dado("digito um código postal")
	public void digito_um_código_postal() {FormularioInsurantDataPagina.codigopostal(navergador).sendKeys("86231231");
	}

	@Dado("digito a cidade")
	public void digito_a_cidade() {FormularioInsurantDataPagina.cidade(navergador).sendKeys("Brisbane");
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Dado("seleciono uma Ocupação")
	public void seleciono_uma_ocupação(){FormularioInsurantDataPagina.ocupacao(navergador).click();
	}

	@Dado("seleciono um hobbies")
	public void seleciono_um_hobbies() {FormularioInsurantDataPagina.hobbie(navergador).click();
	}

	@Dado("insiro um perfil de site")
	public void insiro_um_perfil_de_site() {FormularioInsurantDataPagina.perfilsite(navergador).sendKeys("https://www.facebook.com/r.php?locale=pt_BR&display=page");
	   
	}

	//@Dado("clico em abrir e insiro uma foto no diretorio pessoal")
	//public void clico_em_abrir_e_insiro_uma_foto_no_diretorio_pessoal() {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new io.cucumber.java.PendingException();
	//}

	@Entao("clico no botão next para ir para  o para  Proudct Data")
	public void clico_no_botão_next_para_ir_para_o_para_proudct_data() {FormularioInsurantDataPagina.proximapagina(navergador).click();

	}
	
}
	

	
	